package proyecto_2.main;
import proyecto_2.ui.*;
public class Main{
	public static void main(String[] args){
		UI ventana=new UI();
	}
}
